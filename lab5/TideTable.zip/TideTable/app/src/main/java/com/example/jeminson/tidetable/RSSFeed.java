package com.example.jeminson.tidetable;

/**
 * Created by jeminson on 2017. 7. 16..
 */

import java.util.ArrayList;

public class RSSFeed extends ArrayList<RSSItem> {
    // Extending ArrayList to facilitate possible future features

    // Default Serial ID
    private static final long serialVersionUID = 1L;
}
